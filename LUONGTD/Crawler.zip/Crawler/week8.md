# Web Server Market share
---
## Mô tả:
### 1. Gửi GET request đến các url trong list top-1m.csv. Phân tách HTTP response để lấy thông tin web-server
### 2. Sử dụng 50 spider để cải thiện tốc độ
## Vấn đề:
### 1. Một số website trong list không truy cập được (ví dụ: microsoftonline.com)
### 2. Một số HTTP response không có thông tin về web-server
### 3. Thời gian để chạy hết 1,000,000 url quá lớn
