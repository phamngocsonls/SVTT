- Source: https://scans.io/study/scott-top-one-million
- Updated at 17-10-2018
- To extract this zip file:
```sh
$ jar xvf something.zip
```
