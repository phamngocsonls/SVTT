apps.json file originates from [Wappalyzer tool](https://github.com/AliasIO/Wappalyzer) and is licensed under
GPLv3 license. Copy of the license is contained in main directory of this project.